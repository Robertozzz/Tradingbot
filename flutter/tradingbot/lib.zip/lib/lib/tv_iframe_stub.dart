import 'package:flutter/widgets.dart';

/// Non-web stub; never used on mobile/desktop paths.
Widget buildTradingViewIframe(String symbol) {
  return const SizedBox.shrink();
}
